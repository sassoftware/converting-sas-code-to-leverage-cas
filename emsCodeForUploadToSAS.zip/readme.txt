
- mkdir stage
- mkdir uploads

- modify libname statements in 1.esmStageDataForUpload.sas
- submit to SAS 1.esmStageDataForUpload.sas

- generate the encryption password using PROC PWENCODE
- modify libname and encryption password statements in 2.esmUploads.sas
- submit to SAS 2.esmUploads.sas

- cd ..../uploads 
- modify <customerName>_assessment-key.sas with your encryption key
- zip <customerName>_esm.zip *.sas7bdat

- copy <customerName>_esm.zip to SAS secure SharePoint folder
- copy <customerName>_assessment-key.sas to SAS sercure SharePoint folder
